import type { ReactNode } from "react";

/**
 * InteractiveCard — thẻ có 2 trạng thái (Variant): Default và Hover.
 *
 * Default: scale 1, border mờ, không bóng.
 * Hover:   scale 1.03, border sáng (trắng/xám sáng), drop shadow mờ + inner glow.
 *
 * Chuyển biến bằng "spring animation": CSS transition với easing nảy nhẹ
 * (cubic-bezier overshoot) — cho cảm giác lò xo mà không cần thư viện ngoài.
 */

export function InteractiveCard({
  children,
  onClick,
  className = "",
}: {
  children: ReactNode;
  onClick?: () => void;
  className?: string;
}) {
  const interactive = Boolean(onClick);
  return (
    <div
      role={interactive ? "button" : undefined}
      tabIndex={interactive ? 0 : undefined}
      onClick={onClick}
      onKeyDown={
        interactive
          ? (e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                onClick?.();
              }
            }
          : undefined
      }
      className={[
        "spring-card rounded-2xl border bg-coal outline-none",
        interactive ? "cursor-pointer" : "",
        className,
      ].join(" ")}
    >
      {children}
    </div>
  );
}
