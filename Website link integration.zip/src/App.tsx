import { useState } from "react";
import { nabiLogo } from "./imports/nabiLogo";

const NAV = [
  { label: "Trang chủ", href: "#top" },
  { label: "Giới thiệu", href: "#gioi-thieu" },
  { label: "Sản phẩm", href: "#san-pham" },
  { label: "Dịch vụ", href: "#dich-vu" },
  { label: "Kiểm định", href: "#kiem-dinh" },
  { label: "Liên hệ", href: "#lien-he" },
];

const ABOUT_LEAD =
  "CÔNG TY TNHH THIẾT BỊ CÔNG NGHIỆP NA BI xin trân trọng gửi đến Quý khách hàng lời chúc sức khỏe và thành công. Nhằm đáp ứng nhu cầu sử dụng các loại máy móc thiết bị công nghiệp ngày càng tăng, chúng tôi xin giới thiệu các sản phẩm công nghiệp và dân dụng do công ty cung cấp.";

const ABOUT_ITEMS = [
  { n: "01", body: "Chế tạo và cung cấp các loại Bình Chứa Khí Nén dung tích từ 25 lít đến 15.000 lít, áp suất làm việc 08 – 40 kg/cm². Thiết kế và chế tạo theo mọi yêu cầu, có hồ sơ kiểm định an toàn theo quy định của Nhà nước." },
  { n: "02", body: "Máy nén khí trục vít, công suất từ 10 HP đến 400 HP, áp suất làm việc 10 – 40 kg/cm²." },
  { n: "03", body: "Máy nén khí Piston, công suất từ 1/4 HP đến 20 HP, áp suất làm việc 10 – 40 kg/cm²." },
  { n: "04", body: "Máy sấy khí, lọc khí và phụ tùng thay thế: lọc gió, lọc nhớt, lọc tách, nhớt máy nén khí…" },
  { n: "05", body: "Tư vấn thiết kế và thi công hệ thống khí nén nhà xưởng." },
  { n: "06", body: "Các loại phụ kiện khí nén: van an toàn, đồng hồ áp suất, van xả nước bằng điện…" },
  { n: "07", body: "Thiết bị điện – nước công nghiệp và dân dụng: công tắc, ổ cắm, CB, Inverter, khởi động từ từ Schneider, Mitsubishi, LS; dây & cáp điện Cadivi, Taya; ống và phụ kiện nhựa Bình Minh…" },
  { n: "08", body: "Máy phát điện công suất từ 2.2 KVA đến 2500 KVA." },
];

const u = (id: string) => `https://images.unsplash.com/photo-${id}?w=800&h=800&fit=crop&auto=format`;


/* Kích thước kỹ thuật (mm) theo bảng THÔNG SỐ KỸ THUẬT của NABI. dim = [Φ, A, B, C, D, S, E1, E2] */
type Dim = {
  phi: string; a: string; b: string; c: string; d: string;
  s: string; e1: string; e2: string; inlet: string; outlet: string; pmax: string;
};
const DIMS: Record<string, Dim> = {
  "300":  { phi: "Ø480",  a: "150", b: "1500", c: "350", d: "2000", s: "4",  e1: "—",   e2: "—",   inlet: "25A",  outlet: "25A",  pmax: "10" },
  "500":  { phi: "Ø600",  a: "180", b: "1500", c: "400", d: "2080", s: "5",  e1: "—",   e2: "—",   inlet: "40A",  outlet: "40A",  pmax: "10" },
  "700":  { phi: "Ø700",  a: "160", b: "1500", c: "410", d: "2070", s: "5",  e1: "—",   e2: "—",   inlet: "40A",  outlet: "40A",  pmax: "10" },
  "1000": { phi: "Ø850",  a: "220", b: "1500", c: "470", d: "2140", s: "6",  e1: "150", e2: "190", inlet: "40A",  outlet: "40A",  pmax: "10" },
  "1300": { phi: "Ø965",  a: "220", b: "1500", c: "630", d: "2130", s: "8",  e1: "150", e2: "190", inlet: "50A",  outlet: "30A",  pmax: "10" },
  "1500": { phi: "Ø1050", a: "300", b: "1500", c: "500", d: "2400", s: "8",  e1: "150", e2: "190", inlet: "50A",  outlet: "50A",  pmax: "10" },
  "2000": { phi: "Ø1050", a: "300", b: "2000", c: "600", d: "2870", s: "8",  e1: "150", e2: "190", inlet: "50A",  outlet: "30A",  pmax: "10" },
  "3000": { phi: "Ø1250", a: "370", b: "2000", c: "600", d: "2970", s: "8",  e1: "330", e2: "430", inlet: "80A",  outlet: "80A",  pmax: "10" },
  "4000": { phi: "Ø1450", a: "380", b: "2000", c: "630", d: "3010", s: "10", e1: "330", e2: "430", inlet: "100A", outlet: "100A", pmax: "10" },
  "5000": { phi: "Ø1600", a: "400", b: "2500", c: "650", d: "3050", s: "12", e1: "330", e2: "430", inlet: "100A", outlet: "100A", pmax: "10" },
  "8000": { phi: "Ø1600", a: "400", b: "2500", c: "650", d: "3550", s: "12", e1: "330", e2: "430", inlet: "100A", outlet: "100A", pmax: "10" },
};

/* Bảng "Thông số kỹ thuật Bình khí nén" — dùng chung cho mọi bình */
const TANK_STANDARDS: [string, string][] = [
  ["Tiêu chuẩn thiết kế, chế tạo", "TCVN 8366:2010 ; 6008:2010"],
  ["Tiêu chuẩn thử nghiệm", "TCVN 6154-1996"],
  ["Đặc điểm cấu tạo", "Thân trụ, hai đầu cong dạng elip, đặt đứng hoặc nằm."],
  ["Vật liệu", "Thép tấm SS400 / CT3 / Inox 304 (hoặc vật liệu khác theo yêu cầu)."],
  ["Áp suất thiết kế", "10 kg/cm² (hoặc mức áp suất khác theo yêu cầu)."],
  ["Áp suất làm việc", "08 kg/cm² (hoặc mức áp suất khác theo yêu cầu)."],
  ["Môi chất", "Không khí nén hoặc nước."],
  ["Đặc tính", "Không độc."],
  ["Nhiệt độ tối đa", "100 °C."],
  ["Chi tiết bắt chặt trên thân bình", "Ống thép hàn dính trên thân."],
  ["Ống khí vào / ra", "Số lượng 1 (hoặc nhiều hơn theo yêu cầu)."],
  ["Ống van an toàn / xả đáy / áp kế", "Mỗi loại số lượng 1."],
  ["Ống người chui", "Số lượng 1."],
  ["Công nghệ hàn", "Hàn hồ quang chìm SAW."],
];

const TANK_DESC =
  "Bình được sơn Epoxy chống sét rỉ bên trong và sơn tĩnh điện trang trí bên ngoài. " +
  "Chúng tôi chuyên sản xuất tất cả các loại bình nén khí theo tiêu chuẩn Việt Nam " +
  "TCVN 6153~6156/1996, 6008/1995, TCVN 7472-2005, QCVN 01-2008/BLĐTBXH — dung tích " +
  "đến 50.000 lít, áp suất đến 50 bar. Đầy đủ hồ sơ đăng kiểm và lý lịch kiểm tra xuất xưởng.";

type Tank = { name: string; meta: string; img: string; liter: string | null };

const TANKS: Tank[] = [
  { name: "Bình Chứa Khí 300 Lít", meta: "300 L", img: u("1513069916672-918ea0e44870"), liter: "300" },
  { name: "Bình Chứa Khí 500 Lít", meta: "500 L", img: u("1738918922725-d70c666ddccb"), liter: "500" },
  { name: "Bình Chứa Khí 700 Lít", meta: "700 L", img: u("1627052428109-576e839d100a"), liter: "700" },
  { name: "Bình Chứa Khí 1000 Lít", meta: "1.000 L", img: u("1528823872057-9c018a7a7553"), liter: "1000" },
  { name: "Bình Chứa Khí 1300 Lít", meta: "1.300 L", img: u("1739628301974-c0af207eb069"), liter: "1300" },
  { name: "Bình Chứa Khí 1500 Lít", meta: "1.500 L", img: u("1689348745037-21adeb31dd2a"), liter: "1500" },
  { name: "Bình Chứa Khí 2000 Lít", meta: "2.000 L", img: u("1701441159872-1fcf640e1d56"), liter: "2000" },
  { name: "Bình Chứa Khí 3000 Lít", meta: "3.000 L", img: u("1601406008343-a7211a4ea915"), liter: "3000" },
  { name: "Bình Chứa Khí 4000 Lít", meta: "4.000 L", img: u("1737874132953-b39a4812875d"), liter: "4000" },
  { name: "Bình Chứa Khí 5000 Lít", meta: "5.000 L", img: u("1683617617932-54ad37ae8c02"), liter: "5000" },
  { name: "Bình Chứa Khí 8000 Lít", meta: "8.000 L", img: u("1602860109338-fbb8ed9b8068"), liter: "8000" },
  { name: "Bình Chứa Khí Nằm", meta: "Loại nằm ngang", img: u("1633155569800-cdd472894611"), liter: null },
];

const COMPRESSORS = [
  { name: "Máy Nén Khí Đã Qua Sử Dụng", meta: "Thẩm định · bảo hành", img: u("1569968201228-01aebb252e80") },
  { name: "Máy Nén Khí Hiệu Puma 20Hp", meta: "20 HP", img: u("1655874837055-7adc909ae602") },
  { name: "Máy Nén Khí Puma 15 Hp", meta: "15 HP", img: u("1513828418004-7aa1c7e5c824") },
  { name: "Máy Nén Khí Puma 10 Hp", meta: "10 HP", img: u("1558053604-ecb198495006") },
  { name: "Máy Nén Khí Hiệu Puma 7.5 Hp", meta: "7.5 HP", img: u("1637296001293-43ec1ac4e5ed") },
  { name: "Máy Nén Khí Puma 7.5 Hp", meta: "7.5 HP", img: u("1649262756591-9243702d33d1") },
  { name: "Máy Nén Khí Puma 5 Hp", meta: "5 HP", img: u("1780034766207-494de40e771f") },
  { name: "Máy Nén Khí Hiệu Puma 3 Hp", meta: "3 HP", img: u("1670843837803-8122fdb3d4c4") },
  { name: "Máy Nén Khí Hiệu Puma 1 Hp", meta: "1 HP", img: u("1558972483-a3dc94837da0") },
];

const SERVICES = [
  { no: "01", title: "Sản xuất bình áp lực", body: "Chế tạo bình chứa khí, bình áp lực theo TCVN 6153~6156/1996, dung tích đến 50.000 lít, áp suất đến 50 bar." },
  { no: "02", title: "Lắp đặt hệ thống khí nén", body: "Thiết kế, thi công trọn gói hệ thống máy nén – bình chứa – sấy – lọc – đường ống cho nhà máy." },
  { no: "03", title: "Kiểm định an toàn", body: "Kiểm định kỹ thuật an toàn lao động thiết bị áp lực theo QCVN 01-2008/BLĐTBXH, cấp tem & hồ sơ đăng kiểm." },
  { no: "04", title: "Bảo trì – sửa chữa", body: "Bảo dưỡng định kỳ, cung cấp phụ tùng chính hãng và ứng cứu sự cố khí nén 24/7." },
];

const INSPECTION = [
  { step: "01", title: "Thông báo nhu cầu", body: "Cơ sở gửi yêu cầu kiểm định lần đầu, định kỳ hoặc bất thường bằng văn bản / điện thoại / email." },
  { step: "02", title: "Chuẩn bị hồ sơ", body: "Chuẩn bị tài liệu kỹ thuật của đối tượng kiểm định và cử người đại diện chứng kiến." },
  { step: "03", title: "Tiến hành kiểm định", body: "Đơn vị kiểm định thực hiện theo quy chuẩn kỹ thuật quốc gia trong 04 ngày làm việc." },
  { step: "04", title: "Cấp tem & hồ sơ", body: "Dán tem kiểm định và cấp giấy chứng nhận cho đối tượng đạt yêu cầu theo quy định." },
];


/* ------------------------------------------------------------------ */
/* UI — tối giản                                                       */
/* ------------------------------------------------------------------ */

const PHONE = "093 212 6977";
const wrap = "mx-auto max-w-5xl px-6";

function Section({ id, title, children }: { id?: string; title: string; children: React.ReactNode }) {
  return (
    <section id={id} className="border-t border-line">
      <div className={`${wrap} py-16`}>
        <div className="flex items-center gap-2.5">
          <span className="block h-1.5 w-8 rounded-full bg-marine" />
          <span className="block h-1.5 w-2 rounded-full bg-azure" />
        </div>
        <h2 className="mt-3 font-display text-2xl font-bold tracking-tight text-ink">{title}</h2>
        <div className="mt-6">{children}</div>
      </div>
    </section>
  );
}

function ProductCard({ name, meta, img, onClick }: { name: string; meta: string; img: string; onClick?: () => void }) {
  const Tag = onClick ? "button" : "div";
  return (
    <Tag
      onClick={onClick}
      className="group flex w-full flex-col overflow-hidden rounded-lg border border-line bg-coal p-2.5 text-left transition-colors hover:border-marine"
    >
      <div className="relative aspect-square overflow-hidden rounded bg-void">
        <img
          src={img}
          alt={name}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
        <span className="absolute left-2 top-2 rounded bg-coal/95 px-2 py-0.5 font-mono text-[11px] font-semibold text-deep">
          {meta}
        </span>
      </div>
      <div className="mt-2.5 flex flex-1 flex-col justify-between px-0.5 pb-0.5">
        <h3 className="text-[13.5px] font-semibold leading-snug text-ink group-hover:text-marine">{name}</h3>
        <div className="mt-2 flex items-center justify-between border-t border-line/70 pt-2 text-[11.5px]">
          <span className="text-graphite">{onClick ? "Thông số kỹ thuật" : "Liên hệ báo giá"}</span>
          <span className="font-mono font-semibold text-marine group-hover:text-deep">
            {onClick ? "Chi tiết →" : PHONE}
          </span>
        </div>
      </div>
    </Tag>
  );
}

function Rows({ rows }: { rows: [string, string][] }) {
  return (
    <dl className="divide-y divide-line text-[13.5px]">
      {rows.map(([k, v]) => (
        <div key={k} className="grid gap-1 py-2.5 sm:grid-cols-[210px_1fr] sm:gap-4">
          <dt className="font-medium text-deep">{k}</dt>
          <dd className="text-ink">{v}</dd>
        </div>
      ))}
    </dl>
  );
}

function TankModal({ tank, onClose }: { tank: Tank; onClose: () => void }) {
  const d = tank.liter ? DIMS[tank.liter] : undefined;
  return (
    <div
      className="fixed inset-0 z-[100] flex items-start justify-center overflow-y-auto bg-ink/50 p-4 sm:p-8"
      onClick={onClose}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label={tank.name}
        onClick={(e) => e.stopPropagation()}
        className="relative my-4 w-full max-w-2xl overflow-hidden rounded-xl border border-line bg-coal"
      >
        <div className="flex items-start justify-between gap-4 border-b border-line bg-void px-6 py-4">
          <div>
            <span className="font-mono text-[11px] font-semibold uppercase tracking-wider text-marine">
              Hồ sơ kỹ thuật · {tank.meta}
            </span>
            <h2 className="mt-0.5 font-display text-xl font-bold text-ink">{tank.name}</h2>
          </div>
          <button
            onClick={onClose}
            aria-label="Đóng"
            className="rounded-md border border-line bg-coal px-2.5 py-1 text-[13px] font-medium text-graphite hover:border-marine hover:text-ink"
          >
            ✕ Đóng
          </button>
        </div>

        <div className="p-6 sm:p-8">
          <div className="flex flex-col gap-5 sm:flex-row">
            <img
              src={tank.img}
              alt={tank.name}
              className="h-28 w-28 shrink-0 rounded-lg border border-line object-cover"
            />
            <p className="text-[13.5px] leading-relaxed text-graphite">{TANK_DESC}</p>
          </div>

          <h3 className="mt-7 font-mono text-[12px] font-semibold uppercase tracking-wider text-deep">
            Kích thước tiêu chuẩn (mm)
          </h3>
          <div className="mt-2 rounded-lg border border-line bg-void px-4 py-1">
            {d ? (
              <Rows
                rows={[
                  ["Dung tích", tank.meta],
                  ["Đường kính (Φ)", d.phi],
                  ["A / B / C", `${d.a} / ${d.b} / ${d.c}`],
                  ["D (chiều cao)", `${d.d} mm`],
                  ["S (dày thân)", `${d.s} mm`],
                  ["E1 / E2", `${d.e1} / ${d.e2}`],
                  ["Ống vào / ra", `${d.inlet} / ${d.outlet}`],
                  ["Áp suất max", `${d.pmax} kG/cm²`],
                ]}
              />
            ) : (
              <p className="py-3 text-[13.5px] text-graphite">
                Chế tạo theo yêu cầu — liên hệ để nhận bản vẽ chi tiết.
              </p>
            )}
          </div>

          <h3 className="mt-7 font-mono text-[12px] font-semibold uppercase tracking-wider text-deep">
            Thông số kỹ thuật chung
          </h3>
          <div className="mt-2 rounded-lg border border-line bg-void px-4 py-1">
            <Rows rows={TANK_STANDARDS} />
          </div>

          <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-t border-line pt-5">
            <span className="text-[13px] text-graphite">Cung cấp đầy đủ hồ sơ kiểm định xuất xưởng</span>
            <a
              href="tel:0932126977"
              className="rounded-md bg-marine px-5 py-2.5 text-[14px] font-semibold text-white hover:bg-deep"
            >
              Gọi báo giá · {PHONE}
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [selectedTank, setSelectedTank] = useState<Tank | null>(null);
  const [productTab, setProductTab] = useState<"all" | "tanks" | "compressors">("all");
  const [showSpecTable, setShowSpecTable] = useState(false);

  return (
    <div id="top" className="min-h-screen bg-void font-body text-ink">
      {/* Top utility bar */}
      <div className="border-b border-line bg-coal text-[12px] text-graphite">
        <div className={`${wrap} flex flex-wrap items-center justify-between gap-2 py-2`}>
          <div className="flex items-center gap-2">
            <span className="inline-block h-2 w-2 rounded-full bg-marine" />
            <span className="font-medium text-ink">CÔNG TY TNHH THIẾT BỊ CÔNG NGHIỆP NA BI</span>
            <span className="hidden text-line sm:inline">|</span>
            <span className="hidden font-mono text-[11px] text-deep sm:inline">TCVN 8366:2010 · QCVN 01-2008</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="hidden sm:inline">205/10 Phạm Văn Chiêu, P.14, Gò Vấp, TP.HCM</span>
            <a href="tel:0932126977" className="font-mono font-semibold text-marine hover:text-deep">
              Hotline: {PHONE}
            </a>
          </div>
        </div>
      </div>

      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-line bg-void/95 backdrop-blur">
        <div className={`${wrap} flex items-center justify-between gap-6 py-3.5`}>
          <a href="#top" aria-label="NABI" className="flex items-center gap-3">
            <img src={nabiLogo} alt="NABI — Thiết bị Công nghiệp NA BI" className="h-6 w-auto" />
          </a>
          <nav className="hidden items-center gap-7 md:flex">
            {NAV.slice(1).map((n) => (
              <a
                key={n.label}
                href={n.href}
                className="text-[13px] font-medium text-graphite transition-colors hover:text-marine"
              >
                {n.label}
              </a>
            ))}
          </nav>
          <a
            href="tel:0932126977"
            className="rounded-md bg-marine px-3.5 py-2 text-[13px] font-semibold text-white transition-colors hover:bg-deep"
          >
            Gọi báo giá · {PHONE}
          </a>
        </div>
      </header>

      {/* Hero — Nền sáng công nghiệp hài hòa với #E7E7E4 & #CCCCCC, điểm nhấn 3 tone xanh */}
      <section className="border-b border-line bg-coal">
        <div className={`${wrap} py-12 md:py-16`}>
          <div className="grid items-center gap-8 md:grid-cols-[1.15fr_0.85fr] lg:gap-12">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full border border-line bg-void px-3 py-1 font-mono text-[11px] font-medium tracking-wide text-deep">
                <span className="h-2 w-2 rounded-full bg-azure" />
                TCVN 8366:2010 · QCVN 01-2008/BLĐTBXH
              </div>
              <h1 className="mt-4 font-display text-3xl font-bold leading-tight tracking-tight text-ink sm:text-4xl lg:text-[40px]">
                Bình chứa khí &amp;{" "}
                <span className="text-marine">máy nén khí công nghiệp</span>
              </h1>
              <p className="mt-4 max-w-xl text-[15px] leading-relaxed text-graphite">
                Chế tạo bình áp lực theo tiêu chuẩn Việt Nam, phân phối máy nén khí Puma, máy sấy khí và dịch vụ kiểm định an toàn trọn gói — đầy đủ hồ sơ đăng kiểm xuất xưởng.
              </p>
              <div className="mt-7 flex flex-wrap items-center gap-3">
                <a
                  href="#san-pham"
                  className="rounded-md bg-marine px-5 py-2.5 text-[14px] font-semibold text-white transition-colors hover:bg-deep"
                >
                  Xem sản phẩm
                </a>
                <a
                  href="tel:0932126977"
                  className="rounded-md border border-line bg-void px-5 py-2.5 text-[14px] font-medium text-deep transition-colors hover:border-azure hover:bg-white"
                >
                  Báo giá · {PHONE}
                </a>
              </div>
            </div>

            {/* Khung showcase sản phẩm nền #E7E7E4 + viền #CCCCCC */}
            <div className="rounded-xl border border-line bg-void p-4">
              <div className="grid grid-cols-2 gap-3">
                <a
                  href="#san-pham"
                  onClick={() => setProductTab("tanks")}
                  className="group overflow-hidden rounded-lg border border-line bg-coal p-2.5 transition-colors hover:border-marine"
                >
                  <div className="aspect-[4/3] overflow-hidden rounded bg-void">
                    <img
                      src={TANKS[0].img}
                      alt="Bình chứa khí nén NABI"
                      className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                  </div>
                  <p className="mt-2.5 font-mono text-[10px] font-semibold uppercase tracking-wider text-azure">
                    Chế tạo theo TCVN
                  </p>
                  <p className="mt-0.5 text-[13px] font-semibold text-ink group-hover:text-marine">
                    Bình chứa khí 300L – 8000L
                  </p>
                </a>

                <a
                  href="#san-pham"
                  onClick={() => setProductTab("compressors")}
                  className="group overflow-hidden rounded-lg border border-line bg-coal p-2.5 transition-colors hover:border-marine"
                >
                  <div className="aspect-[4/3] overflow-hidden rounded bg-void">
                    <img
                      src={COMPRESSORS[1].img}
                      alt="Máy nén khí Puma"
                      className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                  </div>
                  <p className="mt-2.5 font-mono text-[10px] font-semibold uppercase tracking-wider text-azure">
                    Chính hãng · Bảo hành
                  </p>
                  <p className="mt-0.5 text-[13px] font-semibold text-ink group-hover:text-marine">
                    Máy nén khí Puma 1 – 20HP
                  </p>
                </a>
              </div>

              <div className="mt-3 flex items-center justify-between rounded-lg border border-line bg-coal px-3.5 py-2.5 text-[12px] text-graphite">
                <span>Hàn hồ quang chìm SAW · Sơn Epoxy &amp; tĩnh điện</span>
                <a href="#kiem-dinh" className="shrink-0 font-semibold text-marine hover:text-deep">
                  Hồ sơ kiểm định →
                </a>
              </div>
            </div>
          </div>

          {/* Thanh thông số năng lực */}
          <dl className="mt-10 grid grid-cols-2 gap-px overflow-hidden rounded-lg border border-line bg-line sm:grid-cols-4">
            <div className="bg-void px-4 py-3.5">
              <dt className="font-mono text-[11px] uppercase tracking-wider text-deep">Dung tích chế tạo</dt>
              <dd className="mt-1 font-display text-lg font-bold text-ink sm:text-xl">25 – 50.000 Lít</dd>
            </div>
            <div className="bg-void px-4 py-3.5">
              <dt className="font-mono text-[11px] uppercase tracking-wider text-deep">Áp suất làm việc</dt>
              <dd className="mt-1 font-display text-lg font-bold text-ink sm:text-xl">08 – 50 bar</dd>
            </div>
            <div className="bg-void px-4 py-3.5">
              <dt className="font-mono text-[11px] uppercase tracking-wider text-deep">Công suất máy nén</dt>
              <dd className="mt-1 font-display text-lg font-bold text-ink sm:text-xl">1/4 – 400 HP</dd>
            </div>
            <div className="bg-void px-4 py-3.5">
              <dt className="font-mono text-[11px] uppercase tracking-wider text-deep">Tiêu chuẩn xuất xưởng</dt>
              <dd className="mt-1 font-display text-lg font-bold text-marine sm:text-xl">100% Đăng kiểm</dd>
            </div>
          </dl>
        </div>
      </section>

      {/* Giới thiệu */}
      <Section id="gioi-thieu" title="Giới thiệu & Năng lực cung ứng">
        <div className="rounded-lg border border-line bg-coal p-5 text-[14px] leading-relaxed text-graphite">
          {ABOUT_LEAD}
        </div>
        <ul className="mt-6 grid gap-4 sm:grid-cols-2">
          {ABOUT_ITEMS.map((it) => (
            <li
              key={it.n}
              className="flex gap-3.5 rounded-lg border border-line bg-coal p-4 text-[13.5px] leading-relaxed text-graphite transition-colors hover:border-azure"
            >
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded bg-marine/10 font-mono text-[12px] font-semibold text-marine">
                {it.n}
              </span>
              <span>{it.body}</span>
            </li>
          ))}
        </ul>
      </Section>

      {/* Sản phẩm */}
      <Section id="san-pham" title="Sản phẩm chủ lực">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line pb-4">
          <div className="flex flex-wrap gap-2">
            {[
              { id: "all", label: "Tất cả sản phẩm (21)" },
              { id: "tanks", label: "Bình chứa khí (12)" },
              { id: "compressors", label: "Máy nén khí Puma (9)" },
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => setProductTab(t.id as "all" | "tanks" | "compressors")}
                className={`rounded-md px-3.5 py-1.5 text-[13px] font-medium transition-colors ${
                  productTab === t.id
                    ? "bg-marine text-white"
                    : "border border-line bg-coal text-graphite hover:border-azure hover:text-ink"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <button
            onClick={() => setShowSpecTable((v) => !v)}
            className="rounded-md border border-line bg-coal px-3.5 py-1.5 font-mono text-[12px] font-medium text-deep transition-colors hover:border-marine hover:text-marine"
          >
            {showSpecTable ? "Ẩn bảng quy cách 300L–8000L" : "Bảng quy cách kích thước (mm)"}
          </button>
        </div>

        {showSpecTable && (
          <div className="mt-5 overflow-x-auto rounded-lg border border-line bg-coal">
            <table className="w-full min-w-[680px] text-left text-[12.5px]">
              <thead className="border-b border-line bg-void font-mono text-[11px] uppercase text-deep">
                <tr>
                  <th className="px-3.5 py-2.5">Dung tích</th>
                  <th className="px-3 py-2.5">Đường kính Φ</th>
                  <th className="px-3 py-2.5">A / B / C</th>
                  <th className="px-3 py-2.5">Cao D</th>
                  <th className="px-3 py-2.5">Dày S</th>
                  <th className="px-3 py-2.5">Ống vào/ra</th>
                  <th className="px-3 py-2.5">Pmax</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {Object.entries(DIMS).map(([liter, d]) => (
                  <tr
                    key={liter}
                    onClick={() => {
                      const found = TANKS.find((t) => t.liter === liter);
                      if (found) setSelectedTank(found);
                    }}
                    className="cursor-pointer transition-colors hover:bg-void"
                  >
                    <td className="px-3.5 py-2 font-semibold text-marine">{liter} Lít</td>
                    <td className="px-3 py-2 font-mono">{d.phi}</td>
                    <td className="px-3 py-2 font-mono">{d.a} / {d.b} / {d.c}</td>
                    <td className="px-3 py-2 font-mono">{d.d} mm</td>
                    <td className="px-3 py-2 font-mono">{d.s} mm</td>
                    <td className="px-3 py-2 font-mono">{d.inlet} / {d.outlet}</td>
                    <td className="px-3 py-2 font-mono">{d.pmax} kG/cm²</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {(productTab === "all" || productTab === "tanks") && (
          <div className="mt-6">
            <div className="flex items-center justify-between">
              <h3 className="font-mono text-[12px] font-semibold uppercase tracking-wider text-deep">
                Bình chứa khí nén (Click để xem thông số kỹ thuật)
              </h3>
              <span className="font-mono text-[12px] text-graphite">300L – 8.000L</span>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
              {TANKS.map((p) => (
                <ProductCard key={p.name} {...p} onClick={() => setSelectedTank(p)} />
              ))}
            </div>
          </div>
        )}

        {(productTab === "all" || productTab === "compressors") && (
          <div className={productTab === "all" ? "mt-12" : "mt-6"}>
            <div className="flex items-center justify-between">
              <h3 className="font-mono text-[12px] font-semibold uppercase tracking-wider text-deep">
                Máy nén khí Puma
              </h3>
              <span className="font-mono text-[12px] text-graphite">1 HP – 20 HP</span>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
              {COMPRESSORS.map((p) => (
                <ProductCard key={p.name} {...p} />
              ))}
            </div>
          </div>
        )}
      </Section>

      {/* Dịch vụ */}
      <Section id="dich-vu" title="Dịch vụ kỹ thuật">
        <div className="grid gap-4 sm:grid-cols-2">
          {SERVICES.map((s) => (
            <div
              key={s.no}
              className="rounded-lg border border-line bg-coal p-5 transition-colors hover:border-azure"
            >
              <div className="flex items-center gap-2.5">
                <span className="rounded bg-marine px-2 py-0.5 font-mono text-[11px] font-semibold text-white">
                  {s.no}
                </span>
                <h3 className="text-[15px] font-semibold text-ink">{s.title}</h3>
              </div>
              <p className="mt-2.5 text-[13.5px] leading-relaxed text-graphite">{s.body}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* Kiểm định */}
      <Section id="kiem-dinh" title="Quy trình kiểm định định kỳ">
        <ol className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {INSPECTION.map((s) => (
            <li key={s.step} className="rounded-lg border border-line bg-coal p-4">
              <span className="inline-block rounded bg-deep px-2.5 py-0.5 font-mono text-[11px] font-medium text-white">
                Bước {s.step}
              </span>
              <h3 className="mt-2.5 text-[15px] font-semibold text-ink">{s.title}</h3>
              <p className="mt-1.5 text-[13.5px] leading-relaxed text-graphite">{s.body}</p>
            </li>
          ))}
        </ol>
      </Section>

      {/* Liên hệ */}
      <Section id="lien-he" title="Liên hệ báo giá">
        <div className="grid gap-6 rounded-xl border border-line bg-coal p-6 md:grid-cols-[1.3fr_0.7fr] md:items-center">
          <Rows
            rows={[
              ["Phụ trách", "Mr. Khải — Phòng kinh doanh"],
              ["Hotline", "093 212 6977 · 098 397 9080"],
              ["Email", "congnghewebblog@gmail.com"],
              ["Địa chỉ", "205/10 Phạm Văn Chiêu, P.14, Q. Gò Vấp, TP. HCM"],
            ]}
          />
          <div className="rounded-lg border border-line bg-void p-5">
            <p className="font-mono text-[11px] font-semibold uppercase tracking-wider text-deep">
              Tư vấn kỹ thuật &amp; Báo giá
            </p>
            <p className="mt-1.5 text-[13.5px] leading-relaxed text-graphite">
              Nhận đặt hàng chế tạo bình chứa khí theo bản vẽ riêng và giao lắp tận nơi trên toàn quốc.
            </p>
            <a
              href="tel:0932126977"
              className="mt-4 inline-block w-full rounded-md bg-marine px-5 py-2.5 text-center text-[14px] font-semibold text-white transition-colors hover:bg-deep"
            >
              Gọi ngay · {PHONE}
            </a>
          </div>
        </div>
      </Section>

      <footer className="border-t border-line bg-coal">
        <div className={`${wrap} flex flex-col justify-between gap-2 py-7 text-[13px] text-graphite sm:flex-row`}>
          <span className="font-medium text-ink">© {new Date().getFullYear()} Công ty TNHH Thiết bị Công nghiệp NA BI</span>
          <span className="text-deep">Đặt uy tín chất lượng lên hàng đầu</span>
        </div>
      </footer>

      {selectedTank && <TankModal tank={selectedTank} onClose={() => setSelectedTank(null)} />}
    </div>
  );
}
